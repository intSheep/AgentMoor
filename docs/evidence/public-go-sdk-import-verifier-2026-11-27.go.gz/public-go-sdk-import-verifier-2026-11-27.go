package main
import (
 "bytes"
 "encoding/json"
 "fmt"
 "go/ast"
 "go/format"
 "go/parser"
 "go/token"
 "os"
 "os/exec"
 "path/filepath"
)
func run(root string,args ...string)[]byte{c:=exec.Command("git",args...);c.Dir=root;b,e:=c.Output();if e!=nil{panic(e)};return b}
func body(source []byte)[]byte{set:=token.NewFileSet();f,e:=parser.ParseFile(set,"source.go",source,parser.ParseComments);if e!=nil{panic(e)};var ds []ast.Decl;for _,d:=range f.Decls{if g,ok:=d.(*ast.GenDecl);ok&&g.Tok==token.IMPORT{continue};ds=append(ds,d)};f.Decls=ds;f.Imports=nil;var b bytes.Buffer;if e:=format.Node(&b,set,f);e!=nil{panic(e)};return b.Bytes()}
func main(){root:=os.Args[1];names:=bytes.Split(run(root,"diff","--name-only","-z","HEAD","--","*.go"),[]byte{0});var checked []string;for _,name:=range names{if len(name)==0{continue};p:=string(name);before:=run(root,"show","HEAD:"+p);after,e:=os.ReadFile(filepath.Join(root,p));if e!=nil{panic(e)};if !bytes.Equal(body(before),body(after)){panic("non-import Go difference: "+p)};checked=append(checked,p)};oldMod:=run(root,"show","HEAD:go.mod");newMod,e:=os.ReadFile(filepath.Join(root,"go.mod"));if e!=nil{panic(e)};if !bytes.Equal(oldMod,bytes.Replace(newMod,[]byte("module github.com/intSheep/AgentMoor"),[]byte("module agentmoor"),1)){panic("go.mod changed beyond module directive")};oldEvidence:=run(root,"diff","--name-only","HEAD","--","docs/evidence");if len(oldEvidence)>0{panic("historical evidence changed")};data,e:=json.MarshalIndent(map[string]any{"base_commit":string(bytes.TrimSpace(run(root,"rev-parse","HEAD"))),"changed_go_files":len(checked),"checked_paths":checked,"non_import_go_body_changes":false,"module_directive_only":true,"historical_evidence_changed":false},"","  ");if e!=nil{panic(e)};if e:=os.WriteFile("/private/tmp/agentmoor-sdk-import-migration-proof-20261127.json",append(data,'\n'),0600);e!=nil{panic(e)};fmt.Println(len(checked),"Go files: bodies identical after removing imports; only module directive changed")}
