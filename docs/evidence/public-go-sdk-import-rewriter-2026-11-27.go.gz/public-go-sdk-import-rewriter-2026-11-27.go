package main

import (
 "bytes"
 "fmt"
 "go/format"
 "go/parser"
 "go/token"
 "os"
 "os/exec"
 "path/filepath"
 "strconv"
 "strings"
)

func main() {
 root := os.Args[1]
 command := exec.Command("git", "ls-files", "-z", "--", "*.go")
 command.Dir = root
 listed, err := command.Output(); if err != nil { panic(err) }
 changed, imports := 0, 0
 for _, name := range bytes.Split(listed, []byte{0}) {
  if len(name)==0 { continue }
  path := filepath.Join(root,string(name))
  source,err := os.ReadFile(path); if err!=nil { panic(err) }
  set:=token.NewFileSet(); file,err:=parser.ParseFile(set,path,source,parser.ParseComments);if err!=nil {panic(err)}
  modified:=false
  for _, declaration:=range file.Imports {
   value,err:=strconv.Unquote(declaration.Path.Value);if err!=nil {panic(err)}
   if strings.HasPrefix(value,"agentmoor/") {
    declaration.Path.Value=strconv.Quote("github.com/intSheep/AgentMoor/"+strings.TrimPrefix(value,"agentmoor/"))
    modified=true;imports++
   }
  }
  if !modified {continue}
  var result bytes.Buffer;if err:=format.Node(&result,set,file);err!=nil {panic(err)}
  info,err:=os.Stat(path);if err!=nil {panic(err)}
  if err:=os.WriteFile(path,result.Bytes(),info.Mode().Perm());err!=nil {panic(err)}
  changed++
 }
 fmt.Printf("rewrote %d imports across %d tracked Go files; string payloads and historical evidence unchanged\n",imports,changed)
}
