import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import tempfile
import time

source = Path('/private/tmp/agentmoor-sdk-starter/examples/sdk-adapter')
proof = Path(tempfile.mkdtemp(prefix='agentmoor-sdk-starter-final-20261128-', dir='/private/tmp'))
consumer = proof / 'consumer'
shutil.copytree(source, consumer)
shutil.copyfile(__file__, proof / 'verify.py')
digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
report = {
    'scope': 'Maintainer-written synthetic filesystem starter copied outside checkout; published alpha.2, not independent human/vendor/task/isolation evidence.',
    'source': str(source), 'consumer': str(consumer),
    'source_sha256': {path.name: digest(path) for path in source.iterdir() if path.is_file()},
    'base_commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=source, text=True).strip(),
    'harness_sha256': digest(Path(__file__)), 'steps': [],
}
env = {name: os.environ[name] for name in ['PATH', 'HOME', 'TMPDIR', 'CC', 'CXX', 'SDKROOT', 'DEVELOPER_DIR', 'MACOSX_DEPLOYMENT_TARGET', 'LANG', 'LC_ALL'] if name in os.environ}
env.update(GOENV='off', GOWORK='off', GOTOOLCHAIN='local', GOPROXY='https://proxy.golang.org', GOSUMDB='sum.golang.org', GONOPROXY='none', GONOSUMDB='none', GOPRIVATE='', GOVCS='*:off', CGO_ENABLED='1', GOTELEMETRY='off', GOFLAGS='-mod=readonly -buildvcs=false')


def run(name, args):
    start = time.monotonic()
    with (proof / (name + '.stdout.log')).open('xb') as stdout, (proof / (name + '.stderr.log')).open('xb') as stderr:
        result = subprocess.run(['go', *args], cwd=consumer, env=env, stdout=stdout, stderr=stderr, timeout=300)
    report['steps'].append({'name': name, 'command': ['go', *args], 'exit_code': result.returncode, 'seconds': round(time.monotonic() - start, 3), 'stdout_sha256': digest(proof / (name + '.stdout.log')), 'stderr_sha256': digest(proof / (name + '.stderr.log'))})
    (proof / 'result.json').write_text(json.dumps(report, indent=2) + '\n')
    if result.returncode:
        raise RuntimeError(f'{name} failed; {proof}')
    return (proof / (name + '.stdout.log')).read_text()


try:
    report['environment'] = json.loads(run('environment', ['env', '-json', 'GOVERSION', 'GOOS', 'GOARCH', 'GOWORK', 'GOMOD', 'CGO_ENABLED']))
    report['module'] = json.loads(run('module', ['list', '-m', '-json', 'github.com/intSheep/AgentMoor']))
    assert report['module']['Version'] == 'v0.1.0-alpha.2' and not report['module'].get('Replace')
    raw = run('tests', ['test', '-mod=readonly', '-json', '-race', '-count=1', '-timeout=90s', './...'])
    events = [json.loads(line) for line in raw.splitlines()]
    passed = [event.get('Test', '') for event in events if event.get('Action') == 'pass']
    assert all(name in passed for name in ['TestNotebookRegistryAndDiscovery', 'TestNotebookAssetContract', 'TestNotebookAssetContract/notebook-files', 'TestNotebookRejectsInvalidSessions', 'TestNotebookRejectsInvalidSessions/oversized', 'TestNotebookRejectsInvalidSessions/inside-symlink', 'TestNotebookRejectsInvalidSessions/outside-symlink', 'TestNotebookCancellation', ''])
    assert any('ADAPTER_CONTRACT mechanism=filesystem' in event.get('Output', '') and 'four_assets=true old_versions=true' in event.get('Output', '') for event in events)
    assert {path.name: digest(path) for path in consumer.iterdir() if path.is_file()} == report['source_sha256']
    report.update(status='passed', tests_passed=passed, consumer_files_unchanged=True)
finally:
    (proof / 'result.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({'proof': str(proof), 'status': report.get('status', 'failed'), 'steps': report['steps']}))
