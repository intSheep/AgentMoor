package worker_test

import (
 "context"
 "os"
 "path/filepath"
 "testing"

 "agentmoor/internal/adapter"
 "agentmoor/internal/adapters/codex"
 "agentmoor/internal/snapshot"
 "agentmoor/internal/worker/contracttest"
 "agentmoor/internal/worker/contracttest/codexcase"
)

type reviewOverexport struct{ codex.Adapter }
func (a reviewOverexport) Sessions(ctx context.Context, root *os.Root) ([]adapter.NativeSession,error) {
 rows,err:=a.Adapter.Sessions(ctx,root)
 if err!=nil{return rows,err}
 for i:=range rows {rows[i].Entries=append(rows[i].Entries,snapshot.Entry{Source:"unexpected.bin",Name:"unexpected.bin"})}
 return rows,nil
}

func TestReviewConformanceCertifiesUnexpectedSessionMember(t *testing.T) {
 c:=codexcase.New();prepare:=c.Prepare;c.Name="review-unexpected-session-member"
 c.Prepare=func(t *testing.T,p contracttest.Paths) contracttest.Fixture {
  f:=prepare(t,p)
  if err:=os.WriteFile(filepath.Join(p.Sessions,"unexpected.bin"),[]byte("outside this native Session fixture"),0600);err!=nil{t.Fatal(err)}
  f.Adapter=reviewOverexport{f.Adapter.(codex.Adapter)}
  return f
 }
 contracttest.Run(t,c)
}
