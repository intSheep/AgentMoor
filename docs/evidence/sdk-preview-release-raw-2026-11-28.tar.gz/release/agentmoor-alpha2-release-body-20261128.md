This is the first AgentMoor **0.x preview with a public Go Adapter SDK**. Gather independent integration feedback before freezing 1.0; public APIs may change during the preview.

In an unrelated Go module, pin the exact version:

```sh
GOWORK=off GOTOOLCHAIN=local go get github.com/intSheep/AgentMoor/sdk@v0.1.0-alpha.2
```

Use `sdk` for adapter interfaces, registration, runtime inspection and explicit trusted CLI helpers. Import the separate `sdk/contracttest` package when you need the shared asset contract suite. Adapters are registered explicitly by trusted startup code; this release does not add dynamic plugin loading or a Hook/RPC protocol.

Requires Go 1.27.4 on Linux/macOS. SDK core builds with CGO disabled; the optional asset runner needs a C compiler, CGO and local HTTP. The original `v0.1.0-alpha.1` tag is preserved and does not contain the SDK. Its module was named `agentmoor`; new source integrations use the canonical `github.com/intSheep/AgentMoor` path.

[SDK guide and compatibility policy](https://github.com/intSheep/AgentMoor/blob/v0.1.0-alpha.2/docs/adapter-sdk.md) · [Changes and migration](https://github.com/intSheep/AgentMoor/blob/v0.1.0-alpha.2/docs/releases/v0.1.0-alpha.2.md) · [Asset contract](https://github.com/intSheep/AgentMoor/blob/v0.1.0-alpha.2/docs/adapter-contract.md)

The release includes the first self-managed Linux/gVisor isolation and operator-only audit work with PostgreSQL/S3 acceptance. Its [security boundary and evidence](https://github.com/intSheep/AgentMoor/blob/v0.1.0-alpha.2/docs/security-boundary.md) remain explicit: this does not certify all CLIs for untrusted isolated tasks, arbitrary escape resistance, HA, or live model integration. Existing model tests use fixed native CLIs with scripted endpoints.

Published-module acquisition is checked separately from local source replacement. Reproduce with `make test-sdk-release VERSION=v0.1.0-alpha.2 SDK_RELEASE_OUTPUT=/absolute/new/evidence`; it uses an unrelated consumer and a dedicated empty module cache, verifies module checksums, builds the SDK core, runs the synthetic native asset suite, and checks Go's internal-package denial. Maintainer and agent rehearsals do not count as real third-party certification. [Current acceptance records](https://github.com/intSheep/AgentMoor/blob/main/docs/adapter-sdk.md).
