module example.invalid/agentmoor-sdk-consumer

go 1.27.4

require github.com/intSheep/AgentMoor v0.1.0-alpha.1.0.20261127122244-283fc010d019
