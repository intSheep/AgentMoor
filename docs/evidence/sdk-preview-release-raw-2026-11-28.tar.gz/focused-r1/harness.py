#!/usr/bin/env python3
"""Archive focused checks against the unchanged release verifier."""
import argparse
import importlib.util
import json
import os
from pathlib import Path
import signal
import subprocess
import threading
import time

OUT = Path(__file__).resolve().parent
SOURCE = Path('/private/tmp/agentmoor-sdk-release/scripts/check-sdk-release.py')
spec = importlib.util.spec_from_file_location('release_check', SOURCE)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
result = {'script': str(SOURCE), 'script_sha256': module.digest(SOURCE), 'checks': {}, 'status': 'failed'}
check = None
real_go = None

def fixture(name, source):
    path = OUT / name
    path.write_text('#!/bin/sh\n' + source)
    path.chmod(0o700)
    return path

def expect_failure(name, executable, timeout=10):
    check.go = str(executable)
    try:
        check.run(name, [], timeout=timeout)
    except RuntimeError as error:
        return str(error)
    raise AssertionError(name + ' unexpectedly succeeded')

def child_stopped(name):
    pid = int((OUT / (name + '.pid')).read_text())
    for _ in range(50):
        probe = subprocess.run(['ps', '-p', str(pid), '-o', 'stat='], capture_output=True, text=True, timeout=3)
        state = probe.stdout.strip()
        if probe.returncode == 1 or state.startswith('Z'):
            return {'pid': pid, 'state_after': state or 'absent', 'not_running': True}
        time.sleep(0.02)
    raise AssertionError('owned child still running: ' + str(pid))

try:
    compile(SOURCE.read_bytes(), str(SOURCE), 'exec')
    result['checks']['syntax'] = 'passed'
    accepted = ['v0.1.0-alpha.2', 'v0.2.3', 'v0.0.1-rc.1', 'v0.1.0-alpha.1.0.20261127122244-283fc010d019']
    rejected = ['latest', 'main', 'v1.0.0', 'v0.01.0', 'v0.1.0-alpha.02', 'v0.1.0+build', 'v0.1.0@main']
    for value in accepted:
        assert module.exact_preview(value) == value
    for value in rejected:
        try:
            module.exact_preview(value)
        except argparse.ArgumentTypeError:
            pass
        else:
            raise AssertionError('unexpected version acceptance: ' + value)
    result['checks']['version_boundary'] = {'passed': True, 'accepted': accepted, 'rejected': rejected}
    check = module.Check('v0.1.0-alpha.2', OUT, SOURCE.parents[1])
    real_go = check.go
    split = fixture('split-go', "printf '{\"value\":true}\\n'\nprintf 'go: downloading fixture\\n' >&2\n")
    check.go = str(split)
    code, raw = check.run('separated-output', [])
    assert code == 0 and json.loads(raw) == {'value': True}
    step = check.report['steps'][-1]
    assert 'go: downloading fixture' in (OUT / step['stderr_log']).read_text()
    result['checks']['separated_streams'] = {'passed': True, 'stdout_log': step['log'], 'stderr_log': step['stderr_log']}
    timeout = fixture('timeout-go', f'sleep 30 &\nprintf "%s\\n" "$!" > {OUT}/timeout.pid\nwait\n')
    message = expect_failure('bounded-timeout', timeout, timeout=0.15)
    assert 'timeout' in message and check.report['steps'][-1]['stopped'] == 'timeout'
    result['checks']['timeout'] = {'passed': True, 'error': message, 'descendant': child_stopped('timeout')}
    output = fixture('output-go', 'yes fixture\n')
    message = expect_failure('bounded-output', output)
    step = check.report['steps'][-1]
    assert 'output limit' in message and step['output_bytes'] <= module.MAX_OUTPUT
    result['checks']['output_bound'] = {'passed': True, 'error': message, 'limit_bytes': module.MAX_OUTPUT, 'logged_bytes': step['output_bytes']}
    interrupted = fixture('interrupted-go', f'sleep 30 &\nprintf "%s\\n" "$!" > {OUT}/interrupted.pid\nwait\n')
    check.go = str(interrupted)
    timer = threading.Timer(0.15, lambda: os.kill(os.getpid(), signal.SIGINT))
    timer.start()
    try:
        check.run('interrupted-process', [], timeout=10)
    except KeyboardInterrupt:
        result['checks']['keyboard_interrupt'] = {'passed': True, 'descendant': child_stopped('interrupted')}
    else:
        raise AssertionError('SIGINT did not interrupt runner')
    finally:
        timer.cancel()
    result['status'] = 'passed'
except BaseException as error:
    result['error'] = repr(error)
finally:
    if check is not None:
        check.go = real_go
        try:
            check.cleanup()
            result['checks']['cleanup'] = check.report['cleanup']
            result['steps'] = check.report['steps']
            assert check.report['cleanup']['go_clean_succeeded']
            assert check.report['cleanup']['temporary_root_removed']
        except Exception as error:
            result['status'] = 'failed'
            result['cleanup_error'] = repr(error)
    result['harness_sha256'] = module.digest(Path(__file__).resolve())
    result['fixture_hashes'] = {path.name: module.digest(path) for path in OUT.glob('*-go')}
    (OUT / 'result.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
raise SystemExit(0 if result['status'] == 'passed' else 1)
