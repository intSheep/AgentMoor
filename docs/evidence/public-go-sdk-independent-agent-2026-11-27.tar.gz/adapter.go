package docsonly

import (
	"context"
	"fmt"
	"io"
	"os"
	"path"
	"strings"

	"github.com/intSheep/AgentMoor/sdk"
)

// Adapter demonstrates an independent text format and an independent marker.
// It has file discovery capabilities, without any task execution capability.
type Adapter struct{}

const (
	marker        = ".aurora-agent"
	skillManifest = ".agents/skills/aurora-clock/SKILL.md"
	sessionFormat = "aurora-note-v1"
)

func (Adapter) Descriptor() sdk.Descriptor {
	capabilities := make(map[sdk.AssetKind][]sdk.Capability)
	for _, kind := range []sdk.AssetKind{sdk.Session, sdk.Skill, sdk.Artifact, sdk.Workspace} {
		capabilities[kind] = []sdk.Capability{
			{Operation: "export", Mode: "filesystem", Reliability: "synthetic-roundtrip"},
			{Operation: "restore", Mode: "filesystem", Reliability: "synthetic-roundtrip"},
		}
	}
	return sdk.Descriptor{ID: "aurora-notes", Version: "0.0.1-preview", Capabilities: capabilities}
}

func (Adapter) Detect(ctx context.Context, root *os.Root) ([]string, error) {
	if err := ctx.Err(); err != nil {
		return nil, err
	}
	if _, err := root.Stat(marker); err != nil {
		if os.IsNotExist(err) {
			return nil, nil
		}
		return nil, err
	}
	return []string{marker}, nil
}

func (Adapter) DiscoverSkills(ctx context.Context, root *os.Root) ([]sdk.SkillRef, error) {
	if err := ctx.Err(); err != nil {
		return nil, err
	}
	if _, err := root.Stat(skillManifest); err != nil {
		if os.IsNotExist(err) {
			return nil, nil
		}
		return nil, err
	}
	return []sdk.SkillRef{{Manifest: skillManifest}}, nil
}

func (Adapter) Sessions(ctx context.Context, root *os.Root) ([]sdk.NativeSession, error) {
	if err := ctx.Err(); err != nil {
		return nil, err
	}
	dir, err := root.Open(".")
	if err != nil {
		return nil, err
	}
	defer dir.Close()
	files, err := dir.ReadDir(-1)
	if err != nil {
		return nil, err
	}
	var sessions []sdk.NativeSession
	for _, file := range files {
		if err := ctx.Err(); err != nil {
			return nil, err
		}
		if file.IsDir() || path.Ext(file.Name()) != ".aurora" {
			continue
		}
		f, err := root.Open(file.Name())
		if err != nil {
			return nil, err
		}
		data, readErr := io.ReadAll(io.LimitReader(f, 65537))
		closeErr := f.Close()
		if readErr != nil {
			return nil, readErr
		}
		if closeErr != nil {
			return nil, closeErr
		}
		if len(data) > 65536 {
			return nil, fmt.Errorf("oversized note %q", file.Name())
		}
		lines := strings.SplitN(string(data), "\n", 3)
		if len(lines) < 3 || lines[0] != "AURORA-NOTE/1" || !strings.HasPrefix(lines[1], "id=") {
			return nil, fmt.Errorf("invalid note %q", file.Name())
		}
		id := strings.TrimPrefix(lines[1], "id=")
		if id == "" {
			return nil, fmt.Errorf("missing note id")
		}
		sessions = append(sessions, sdk.NativeSession{ID: id, Format: sessionFormat, Raw: true, Entries: []sdk.Entry{{Source: file.Name(), Name: file.Name()}}})
	}
	return sessions, nil
}

var _ sdk.Adapter = Adapter{}
var _ sdk.SkillDiscoverer = Adapter{}
var _ sdk.SessionSource = Adapter{}
