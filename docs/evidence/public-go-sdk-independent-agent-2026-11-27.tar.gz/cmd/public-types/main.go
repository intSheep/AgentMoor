package main

import (
	"fmt"
	"github.com/intSheep/AgentMoor/sdk"
	"github.com/intSheep/AgentMoor/sdk/contracttest"
	"reflect"
)

func describe(name string, t reflect.Type) {
	fmt.Printf("%s kind=%s type=%s\n", name, t.Kind(), t)
	if t.Kind() == reflect.Struct {
		for i := 0; i < t.NumField(); i++ {
			f := t.Field(i)
			if f.IsExported() {
				fmt.Printf("  field %s %s tag=%q\n", f.Name, f.Type, f.Tag)
			}
		}
	}
	for i := 0; i < t.NumMethod(); i++ {
		m := t.Method(i)
		fmt.Printf("  method %s %s\n", m.Name, m.Type)
	}
}
func main() {
	describe("sdk.Adapter", reflect.TypeFor[sdk.Adapter]())
	describe("sdk.Descriptor", reflect.TypeFor[sdk.Descriptor]())
	describe("sdk.Capability", reflect.TypeFor[sdk.Capability]())
	describe("sdk.SkillRef", reflect.TypeFor[sdk.SkillRef]())
	describe("sdk.SkillDiscoverer", reflect.TypeFor[sdk.SkillDiscoverer]())
	describe("sdk.SessionSource", reflect.TypeFor[sdk.SessionSource]())
	describe("sdk.NativeSession", reflect.TypeFor[sdk.NativeSession]())
	describe("sdk.Entry", reflect.TypeFor[sdk.Entry]())
	describe("sdk.Registry", reflect.TypeFor[*sdk.Registry]())
	describe("contracttest.Case", reflect.TypeFor[contracttest.Case]())
	describe("contracttest.Paths", reflect.TypeFor[contracttest.Paths]())
	describe("contracttest.Fixture", reflect.TypeFor[contracttest.Fixture]())
	describe("contracttest.Calls", reflect.TypeFor[contracttest.Calls]())
	describe("contracttest.NativeFixture", reflect.TypeFor[contracttest.NativeFixture]())
	fmt.Printf("constants: %q %q %q %q filesystem=%q\n", sdk.Session, sdk.Skill, sdk.Artifact, sdk.Workspace, contracttest.Filesystem)
}
