from pathlib import Path
import os, subprocess, sys, time
root=Path(__file__).parent
env=dict(os.environ,GOWORK="off",GOTOOLCHAIN="local",GOPROXY="off",GOSUMDB="off",GOCACHE=str(root/"go-build"),TMPDIR=str(root/"tmp"))
args=sys.argv[2:]
start=time.time()
try:
 p=subprocess.run(["go"]+args,cwd=root,env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=30)
 text=p.stdout; code=p.returncode
except subprocess.TimeoutExpired as e:
 text=(e.stdout or b"").decode() if isinstance(e.stdout,bytes) else (e.stdout or "")
 text += "\nTIMEOUT after 30 seconds\n"; code=124
(root/sys.argv[1]).write_text(text)
print(text,end="")
print("\ncommand exit="+str(code)+" elapsed="+str(round(time.time()-start,2)))
sys.exit(code)
