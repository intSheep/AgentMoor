Independent SDK public-docs rehearsal

Result: actual race test PASS, public contract runner four-assets and old-versions assertion emitted.
This is an independent agent exercise, not a human external-engineer certification.

Manual material used: docs/adapter-sdk.md, sdk/sdk.go, sdk/contracttest/contracttest.go,
public go doc output, and exported Go reflection (cmd/public-types/main.go).
No manual internal/, sdk tests, testdata/sdkconsumer/, or existing Adapter source reads.
The initial document was not fully sufficient: see result.json and public-types.log.
Its initial SHA256 is saved in public-sources.json. No updated document was consumed.

No SDK checkout files were written. Consumer imports only standard library and the
public sdk / sdk/contracttest packages. Go compiler transitively compiled internal
implementation packages, as permitted. No dependency downloads were enabled.

Reproduce on the same checkout and existing cached dependencies:
  python3 run-go.py repeat.log test -mod=mod -race -count=1 -timeout=60s -v .
The wrapper sets offline/local-toolchain variables and a 30-second outer bound.
The suite needs permission to bind loopback HTTP, plus existing CGO tooling.

Source: adapter.go, adapter_test.go, go.mod, go.sum
Public API assistance: cmd/public-types/main.go, go-doc-*.log, public-types.log
Resolved SDK: sdk-module-resolution.json
Failed environment attempts preserved: go-mod-tidy*.log, go-test-race-attempt-1.log
Authorized successful attempt: go-test-race-attempt-2.log
Final result after a stronger directory nonoverlap assertion: go-test-race.log

The evidence archive excludes the disposable build cache and temporary directory.
All original files remain in this directory.
