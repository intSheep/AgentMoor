package docsonly

import (
	"os"
	"path/filepath"
	"strings"
	"testing"

	"github.com/intSheep/AgentMoor/sdk"
	"github.com/intSheep/AgentMoor/sdk/contracttest"
)

func TestPublicDocsOnlyAssetRoundtrip(t *testing.T) {
	adapter := Adapter{}
	registry, err := sdk.NewRegistry(adapter)
	if err != nil {
		t.Fatal(err)
	}
	registered, err := registry.Lookup("aurora-notes")
	if err != nil {
		t.Fatal(err)
	}
	if len(registry.All()) != 1 {
		t.Fatal("unexpected registry population")
	}
	if err := contracttest.ValidateDescriptor(registered); err != nil {
		t.Fatal(err)
	}
	contracttest.Run(t, contracttest.Case{Name: "aurora-public-docs-only-files", Prepare: func(t *testing.T, p contracttest.Paths) contracttest.Fixture {
		t.Helper()
		for _, assetPath := range []string{p.Workspace, p.Sessions} {
			for _, pair := range [][2]string{{assetPath, p.Runtime}, {p.Runtime, assetPath}} {
				rel, err := filepath.Rel(pair[0], pair[1])
				if err != nil {
					t.Fatal(err)
				}
				if rel != ".." && !strings.HasPrefix(rel, ".."+string(filepath.Separator)) {
					t.Fatal("runtime and asset directories must not overlap")
				}
			}
		}
		if err := os.MkdirAll(p.Workspace, 0700); err != nil {
			t.Fatal(err)
		}
		if err := os.MkdirAll(p.Sessions, 0700); err != nil {
			t.Fatal(err)
		}
		if err := os.WriteFile(filepath.Join(p.Workspace, marker), []byte("aurora synthetic workspace\n"), 0600); err != nil {
			t.Fatal(err)
		}
		original := []byte("AURORA-NOTE/1\nid=aurora-17\nuser: 小船什么时候出发？\nassistant: At dawn.\n\n")
		if err := os.WriteFile(filepath.Join(p.Sessions, "thread.aurora"), original, 0600); err != nil {
			t.Fatal(err)
		}
		return contracttest.Fixture{Adapter: registered, Mechanism: contracttest.Filesystem, SessionID: "aurora-17", SessionFormat: sessionFormat, SkillManifest: skillManifest, SessionFiles: map[string][]byte{"": original}}
	}})
}
